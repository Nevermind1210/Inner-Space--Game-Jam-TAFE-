var class_spaceship_controller =
[
    [ "accelerationSpeed", "class_spaceship_controller.html#a39159e52f3892ddd0fd2510a5e2dca14", null ],
    [ "cameraPosition", "class_spaceship_controller.html#ac94463c456761f408ad59db1c7ffc2c5", null ],
    [ "cameraSmooth", "class_spaceship_controller.html#a853f17644cd2e71f8014be12cec29618", null ],
    [ "crosshairTexture", "class_spaceship_controller.html#aa844030f30ce4ac8a650773c9175b650", null ],
    [ "mainCamera", "class_spaceship_controller.html#a2c1b587e5708e3e3ae9ffe1ba21a6a25", null ],
    [ "normalSpeed", "class_spaceship_controller.html#a54be716a9625438e8d03879ff2eaa1ac", null ],
    [ "rotationSpeed", "class_spaceship_controller.html#af13ae34afee58fe0aed5aa703ed4c5bd", null ],
    [ "spaceshipRoot", "class_spaceship_controller.html#ac510bb5ce9461bbb31495e939fa7ab22", null ]
];