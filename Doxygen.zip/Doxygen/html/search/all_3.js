var searchData=
[
  ['fullscreentoggle_12',['fullscreenToggle',['../class_options_menu.html#a8f97375fce1e2a41cba48e0af7e33f09',1,'OptionsMenu']]]
];
