var searchData=
[
  ['resolutiondropdown_83',['resolutionDropdown',['../class_options_menu.html#a4e6dede35149703c4f09522419cef6f6',1,'OptionsMenu']]],
  ['rotationspeed_84',['rotationSpeed',['../class_spaceship_controller.html#af13ae34afee58fe0aed5aa703ed4c5bd',1,'SpaceshipController']]]
];
