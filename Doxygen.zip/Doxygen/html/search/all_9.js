var searchData=
[
  ['qualitydropdown_23',['qualityDropdown',['../class_options_menu.html#a2056f92534245f59f8d7fc9b457a9057',1,'OptionsMenu']]],
  ['quitgame_24',['QuitGame',['../class_main_menu.html#a485db7cf60c0b93ecc87b9273bcce78b',1,'MainMenu']]]
];
