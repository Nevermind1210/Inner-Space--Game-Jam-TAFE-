var searchData=
[
  ['qualitydropdown_82',['qualityDropdown',['../class_options_menu.html#a2056f92534245f59f8d7fc9b457a9057',1,'OptionsMenu']]]
];
