var searchData=
[
  ['loaddata_13',['loadData',['../class_options_menu.html#aa40b6aa469d7f5cd372206fedfa06322',1,'OptionsMenu']]],
  ['loadsettings_14',['LoadSettings',['../class_options_menu.html#af5e5164beae74bbe7a7587c8ebb53d3c',1,'OptionsMenu']]]
];
