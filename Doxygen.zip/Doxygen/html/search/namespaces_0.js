var searchData=
[
  ['defaultnamespace_52',['DefaultNamespace',['../namespace_default_namespace.html',1,'']]]
];
