var searchData=
[
  ['savesettings_30',['SaveSettings',['../class_options_menu.html#a150d697261279e862c8da460dbcd68e6',1,'OptionsMenu']]],
  ['setantialiasing_31',['SetAntiAliasing',['../class_options_menu.html#a3f60ae7b162df54afdd83a4aede68c8d',1,'OptionsMenu']]],
  ['setfullscreen_32',['SetFullScreen',['../class_options_menu.html#a2e6603c77fd7987899f23d446feba850',1,'OptionsMenu']]],
  ['setmastervolume_33',['SetMasterVolume',['../class_options_menu.html#a8b92b383d30672dd48f1758369745209',1,'OptionsMenu']]],
  ['setquality_34',['SetQuality',['../class_options_menu.html#ab17e07a4c66e345e3eb4b6cf1b3114d9',1,'OptionsMenu']]],
  ['setresolution_35',['SetResolution',['../class_options_menu.html#aa66b7a6ec22e87d7bf4b4b4c242d1f35',1,'OptionsMenu']]],
  ['settexturequality_36',['SetTextureQuality',['../class_options_menu.html#a14152259ae83ddddfb45f0723f8ac998',1,'OptionsMenu']]],
  ['sfxvolume_37',['SFXVolume',['../class_options_menu.html#a752133edaf972c0b547d2e8be3d9354c',1,'OptionsMenu']]],
  ['sfxvolumeslider_38',['sfxVolumeSlider',['../class_options_menu.html#af33cfcef1efeea8650d386d8ef8d85c8',1,'OptionsMenu']]],
  ['spaceshipcontroller_39',['SpaceshipController',['../class_spaceship_controller.html',1,'']]],
  ['spaceshipcontroller_2ecs_40',['SpaceshipController.cs',['../_spaceship_controller_8cs.html',1,'']]],
  ['spaceshiproot_41',['spaceshipRoot',['../class_spaceship_controller.html#ac510bb5ce9461bbb31495e939fa7ab22',1,'SpaceshipController']]]
];
