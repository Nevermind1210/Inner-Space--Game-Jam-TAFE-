var searchData=
[
  ['loadsettings_60',['LoadSettings',['../class_options_menu.html#af5e5164beae74bbe7a7587c8ebb53d3c',1,'OptionsMenu']]]
];
