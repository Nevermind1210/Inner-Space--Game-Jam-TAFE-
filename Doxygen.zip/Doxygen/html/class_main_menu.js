var class_main_menu =
[
    [ "PlayGame", "class_main_menu.html#a11d7e3cd6b90cf59659e03e830e02db5", null ],
    [ "QuitGame", "class_main_menu.html#a485db7cf60c0b93ecc87b9273bcce78b", null ]
];