var class_options_menu =
[
    [ "Awake", "class_options_menu.html#a3cdd7c76000cfbbb1245eee8aa6b233f", null ],
    [ "LoadSettings", "class_options_menu.html#af5e5164beae74bbe7a7587c8ebb53d3c", null ],
    [ "SaveSettings", "class_options_menu.html#a150d697261279e862c8da460dbcd68e6", null ],
    [ "SetAntiAliasing", "class_options_menu.html#a3f60ae7b162df54afdd83a4aede68c8d", null ],
    [ "SetFullScreen", "class_options_menu.html#a2e6603c77fd7987899f23d446feba850", null ],
    [ "SetMasterVolume", "class_options_menu.html#a8b92b383d30672dd48f1758369745209", null ],
    [ "SetQuality", "class_options_menu.html#ab17e07a4c66e345e3eb4b6cf1b3114d9", null ],
    [ "SetResolution", "class_options_menu.html#aa66b7a6ec22e87d7bf4b4b4c242d1f35", null ],
    [ "SetTextureQuality", "class_options_menu.html#a14152259ae83ddddfb45f0723f8ac998", null ],
    [ "SFXVolume", "class_options_menu.html#a752133edaf972c0b547d2e8be3d9354c", null ],
    [ "aaDropdown", "class_options_menu.html#a190d594ea1643b7178d1cf3688b47d25", null ],
    [ "audioMixer", "class_options_menu.html#a4193226c86c63ce39340f40b75deae64", null ],
    [ "fullscreenToggle", "class_options_menu.html#a8f97375fce1e2a41cba48e0af7e33f09", null ],
    [ "masterVolume", "class_options_menu.html#a88c64b95a6a2cccb017bf581aeca8944", null ],
    [ "qualityDropdown", "class_options_menu.html#a2056f92534245f59f8d7fc9b457a9057", null ],
    [ "resolutionDropdown", "class_options_menu.html#a4e6dede35149703c4f09522419cef6f6", null ],
    [ "sfxVolumeSlider", "class_options_menu.html#af33cfcef1efeea8650d386d8ef8d85c8", null ],
    [ "textureDropdown", "class_options_menu.html#a58b4424867a440ed9252af08edf6c1ce", null ]
];