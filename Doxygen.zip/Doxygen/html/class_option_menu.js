var class_option_menu =
[
    [ "Awake", "class_option_menu.html#a457b3a6896d60165d7d39c9d6bd19e31", null ],
    [ "SetFullScreen", "class_option_menu.html#a386dc12a3f56eb017b7823c21bc74bb4", null ],
    [ "SetMasterVolume", "class_option_menu.html#a007d37a9090af6d15bdc7bdb7e31334c", null ],
    [ "SetQuality", "class_option_menu.html#a2b50ecdba2f977ad68e3dbbdfd70dd4e", null ],
    [ "SetResolution", "class_option_menu.html#a04298e1191f6521380502903bd3837cd", null ],
    [ "SetTextureQuality", "class_option_menu.html#afe5f7eeddf106e527818b221be5ea56f", null ],
    [ "SFXVolume", "class_option_menu.html#a394ca18537aff9d2cbea158a5d90f036", null ],
    [ "audioMixer", "class_option_menu.html#ac0a9189c75842c35742ad69c149e3eb1", null ],
    [ "fullscreenToggle", "class_option_menu.html#a3976c4dde68be3f622f1de9b5b499717", null ],
    [ "masterVolume", "class_option_menu.html#a46636350e0e09262268bfeb82a932b44", null ],
    [ "qualityDropdown", "class_option_menu.html#a2fe77094fcf70f313d5c3c509ea211e2", null ],
    [ "resolutionDropdown", "class_option_menu.html#ab3f28bcc183f6e1cd90b2dbe093ad3ee", null ],
    [ "sfxVolumeSlider", "class_option_menu.html#ae6179d6ea9717f2064fd46212af69653", null ],
    [ "textureDropdown", "class_option_menu.html#a32f124556e8578430091a353babdec26", null ]
];