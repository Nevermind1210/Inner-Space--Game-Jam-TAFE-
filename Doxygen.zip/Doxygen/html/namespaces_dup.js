var namespaces_dup =
[
    [ "DefaultNamespace", "namespace_default_namespace.html", "namespace_default_namespace" ]
];