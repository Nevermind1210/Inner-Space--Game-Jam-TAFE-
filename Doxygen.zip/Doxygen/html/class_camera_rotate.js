var class_camera_rotate =
[
    [ "xSpeed", "class_camera_rotate.html#a0939da42356719e8a97c368a76c16cde", null ],
    [ "ySpeed", "class_camera_rotate.html#ab2f311183d1debd8af24d95fff9f43f8", null ],
    [ "zSpeed", "class_camera_rotate.html#a1796e9a3208bcdb6380bb2419a28afdb", null ]
];